---
prev: false
next: ./KarsilasabileceginizProblemler
---

# KARŞILAŞABİLECEĞİNİZ PROBLEMLER

![akışlar](./img/online_transactions.svg)

[[toc]]

## Kurulum Sonrası Sell - Buy Butonları Gözükmüyor

Lisanslama problemini göstermektedir. Öncelikle Chrome gibi her hangi bir web browser üzerinden forex21.com adresine gitmeyi deneyiniz. Eğer gidemez iseniz firewall (güvenlik duvarından) izin vermeyi eğer sorun çözülmez ise DNS sunucusu olarak 8.8.8.8 olarak yapıp bir daha deneyiniz.

Eğer Browser üzerinden erişebiliyorsanız Meta Trader üzerindeki Tools (Araçlar) >> Options (Seçenekler) >> Expert Advisors (Otomatik Alım Satım)  altına https://forex21.com adresi eklenmemiş olabilir.

Eğer tüm bunlar tamam ise Meta Trader uygulamasının sol üst taraftaki Yıldızlı Klasöre basın. Sonra açılan menüden Scripts tabı altındaki "Account Utility Tool" u çift tıklayıp açılan ekrandaki bilgileri support@forex21.com adresine mail atınız.

![Forex21 AUT](https://lh3.googleusercontent.com/oRmuwt9x1OzTZLO0viOcGVfs7yCJao4UtZr5TMjTRHvU1knQSDNvJC0uBoAd5rGuWBJuM5cQtUs "Forex21 AUT")


## Grafik ekran üzerinden Sell (Satım) - Buy (Alım) butonlarına basıyorum işlem yapmıyor
Bu problemin 2 ihtimali var:
Birincisi Meta Trader uygulaması üzerindeki AutoTrader (OtomatikAlımSatım) kırmızıdır. Aktif yapmak için butona basınız.

![Trader](https://lh3.googleusercontent.com/KH6zvhYwrHVu5qjmzkF5yUJud79q4Na_0rRQ91aBmaIGoXvEck-OFRDU1hluliVIi3DjAmvwKrQ "Trader Otomatik Alım Satım Butonu")

ikinci ihtimal ise her bir ürün en fazla girilecek işlem adedini aşmışsınızdır. Bunun konrolü için işlem yapamadığınız ürünün grafik ekran üzerinde sağ tıklayıp 
