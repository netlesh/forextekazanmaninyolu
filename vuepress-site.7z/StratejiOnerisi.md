# PROFX için ÖNERDİĞİM STRATEJİ

![plan](./img/master_plan.svg)

[[toc]]

 ProFX ile kazanmak çok kolay.  Aşağıda kendi uyguladığım stratejimi yazıyorum. Bu yöntem ile 3 yıllık zararımı çıkartıp artıya geçtim.  Bu işin sırrı her bir işlemde az getiriye razı olmaktan geciyor. 
 
 Stratejinin başarılı olabilmesi için öncelikle bazı gereksinimlerinsağlanması gerekiyor.
 
## Gereksinimler:

 ### 1. Swapsız Hesap:
 SWAP açtığınız işlem için aldığınız veya ödediğiniz günlük faiz bedelidir. Her ne kadar ProFX anlık sinyal verse de o işleminin kapanması zaman alabiliyor. Bazen sinyal verdikten kısa süre sonra işlemde ters sinyal verebilir.  ProFX anlık  sinyal verse bile bazen işlem o gün kapanmıyor. Bu nedenden ötürü swap devreye girip kazancınızı götürmesin diye işlem yapacağınız hesabın swapsız olması gerekmektedir.
 
Ben EKOLFX'i kullanıyorum. Sitede detaylı avantajlarından bahsettim. Aşağıdaki link ile hesap açabilirsiniz.
[Hesap Aç](https://www.ekolfx5.com/hesap-ac?ref=1959&utm_source=refout&utm_term=1959)

### 2. Düşük Spread
Spread; Bir döviz kurunun alış fiyatı ile satış fiyatı arasındaki farkı ifade eder. Bazen piyasa çok hareketli oluyor. ProFX sinyal verdikten bir süre sonra ters işlemde sinyal üretebiliyor. Eğer düşük al - sat oranlı çalışıyorsanız hareketli zamanalarda bile işleme girdiğinizden kısa süre içinde hızlıca kar alıp cıkarsınız.

 ### 3. Micro Lot - İşlem Size
Forex piyasasında ise 1 lot, 100.000 birimin bir araya gelmesiyle oluşan büyüklüktür. Forex piyasasında  için belirleyeceğiniz işlem büyüklüğü lot ile ifade edilir ve işleminiz sisteme lot olarak girilir. Kısacası, bir parite için 1 lot, döviz kurunun sol tarafındaki birimden 100.000 adetlik bir büyüklüğü temsil eder.

Bakiyeniz ve teminat seviyeniz ne kadar yüksek olursa olsun ProFX üzerinden gelen her sinyali değerlendirebilmek için lot miktarını 0,01 ile 0,05 arasında belirleyip işlem açabilmeniz gerekmekte. Eğer yüksek lot ile giriş yaparsanız terste kaldığınızda teminatınız azaltıp rikte bırakabilir.

### 4. Ürünün Spot Piyasadan Fiyatlanması
Bir çok FX firması DAX, Petrol gibi ürünlerde vadeli kontratlar ile çalışıyor. Buda bir anda çok kazanıp veya kaybetmenize neden oluyor. Buna ek olarak vadeli kontratlarda vade sonunda ya pozisyonu kapatıyor yada ek ücret talep edilmekte. 

EkolFX'in en çok sevdiğim yanı spot yani işlem gördüğü gerçek fiyat üzerinden işlem yapması. Bu sayede gönül rahatlığı ile uzun süreli DAX, Petrol gibi ürünlerde işlem yapmanızı kolaylaştırıyor. EN önemlisi Trend yönünü bldiğin üründe yüksek getiriyi sağlaması.
[Hesap Aç](https://www.ekolfx5.com/hesap-ac?ref=1959&utm_source=refout&utm_term=1959)

## Stratejim: 

### 1. Az Kazanca Razı Olma
Pips; Bir yatırım aracının fiyat olarak hareket edebileceği en küçük birimdir. Örnek EUR/USD paritesi 1,2567 iken bir süre sonra 1,2577 olmuşsa biz buna “EUR/USD 10 pip yükseldi” deriz. 

Her ürün için pips değeri değişeceğinden Ben kar al noktasını belirlerken 0,01'e 1 usd kazanacak yeri bulup ProFX'de TP (Take Profit - Kar Al) olarak giriyorum. Yatay piyasada ProFX ile düşük pips'de yüksek kazanç elde edebilirsiniz. Aşağıda linkten benim kullandığım ProFX ayarlarına ulaşabilirsiniz.
::: tip YARDIM
[ProFX için MT4 Presents Klasörü](https://drive.google.com/drive/folders/1bfID31XbvavNcOo1jj7HJzBB_QwR9-uV?usp=sharing)
:::

### 2. SL (Stop Lost - Zarar Kes) Girmemek

Eğer benim gibi sizde swapsız, düşük pips ve mikro lot ile işlem yapıyorsanız zarar kes yapmanızı önermiyorum. Çünkü ProFX bir ürün için bir sinyal verdi ise o ürün eninde sonunda o fiyata gelecektir.  

** ilk etapta zarar olsada sonradan artıya geciyor. beklemeyi bileceksin sadece. 

### 3. Günlük Kazanç Limiti Belirleme

Kendiniz için günlük kazanç limiti belirtin ve bu limite ulaştığınızda yeni işlem girişi yapmayın. Çünkü bir süre sonra bekleyen çok sayıda işleminiz olabilir. 

Burada dikkat edilecek nokta teminat oranınızı %300'ün altına indirmemek. Yoksa bir anda hesabınızı sıfırlayabilirsiniz. Derler ki " Kar cepte güzeldir. Karı gördün mü al kaç" 

### 4. Time Periots
Ben 5 dakikalık peryotta grafiklere bakmaktayım. 5 dakika hareketliliği görüp kazancı alıp kaçmak için ideal. Eğer ProFX çok sinyal verip sizi yanıltıyorsa süreyi yükseltebilirsiniz. 

## İşlem Yaptığım Ürünler
Sonunda :chart: olanlar başlangıç için tercih edilebilir.

| KOD           | İSİM                 | Tercih  |
| ------------- |:--------------------:| -------:|
| EUR/USD       | Euro - Dolar         | :chart: |
| GBP/USD       | Sterlin - Dolar      | :chart: |
| EUR/GBP       | Euro - Sterlin       |         |
| USD/JPY       | Dolar - Japon Yeni   |         |
| GBP/JPY       | Sterlin - Japon Yeni |         |
| USD/CAD       | Dolar - Kanada Doları| :chart: |
| USD/CHF       | Dolar - İşveç Frangı |         |
| AUD/USD       | Avusturalya - Dolar  |         |
| USD/CNH       | Dolar - Cin Yuan     |         |
| BRN/USD       | Brend Petrol         |         |
| WTI/USD       | Ham Petrol           | :chart: |
| BTC/USD       | Bitcoin              |         |
| XAU/USD       | Ons Altın            | :chart: |
| XAG/USD       | Gümüş                |         |
| DAX/EUR       | Alman Dax Endeksi    |         |
