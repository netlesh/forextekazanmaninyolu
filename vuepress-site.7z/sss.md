# ProFX Sıkca Sorulan Sorular

![SSS](./img/quiz.svg)

[[toc]]

## İslami olarak Forex Caiz mi?

Hayır Caiz Değil. Burada elde edilecek para **Haram**dır. 
Ben buradan harama teşvik etmiyorum. Buradan sadece Forex ile işlem yapanların kazancını nasıl arttırabileceklerini anlatıyorum.

## Bu bir robot mu?

Hayır. ProFX; otomatik alım satım yapan robot veya EA denilen Expert Advisor olmadığı için Türkiye dahil robot çalıştırmayı engelleyen tüm Forex Broker (Aracı Kurum) firmalarında çalıştırabilirsiniz. Size sadece işleme gireceğiniz yönü ve yeri Meta Trader 4 grafik penceresinde sinyal vererek göstermekte 

## Hangi Platformu Destekliyor?

Şuanda sadece Meta Trader 4 (MT4) desteği bulunmakta

## Nasıl Çalışıyor?

ProFX aslında **lisanslı** bir template. MT4 üzerinde açtığınız grafik penceresine ProFX template'ini ekliyorsunuz. Sonrasında lisans kontrolü yapıyor. Eğer kurulum sonrasında MT4 bilgilerinizi support@forex21.com adresine mail attı iseniz "Örnek Görüntüler" sayfasındaki gibi SHELL - BUY butonlarını görürsünüz.

## ProFX Nasıl Satın Alınır?

Aşağıdaki linki tıklayın gelen sayfada "Download your personel copy" linkini tıklayarak satın alım sayfasından sanal kredi kartınız ile  alım yapabilirisiniz. Sanal kartınız yoksa internet bankacılığından ücretsiz oluşturup limit ataması yaparak işleme devam edebilirsiniz. 

Tabiki normal kredi kartınızlada alım yapabilirsiniz.


**Not1:** Bu işlem için kartınızın yurt dışı alış verişine açık olması gerekmektedir.
**Not2:** Satın alım yaparken geçerli ve çalışan mail adresinizi veriniz. Kurulum dosyaları bu mail adresine gelecektir.

## ProFX'i Kaç Hesapta Kullanabilirim?

ProFX'in lisansı Meta hesabınıza göre verilmektedir. En fazla 3 hesap için lisanslama yapılmaktadır.

## Hangi Seviyeden İşleme Başlanmalı

Önce her bir işlem için 0,01'lik lot miktarı ve 1 usd'lik kar ile başlayın. 1 ayın sonunda açtığınız işlem sayısına ve teminatınıza göre lot miktarını arttırın. Fakat pips değerini yükseltmeyin eğer yükseltecekseniz bile çok yükseltmeyin.

## Bizim Bu İşten Çıkarımız Ne?

Eğer site üzerindeki linkten alım yaparsanız ufak bir satış komisyonu almaktayız.

## Amacınız Ne?

Türk halkının daha fazla para kaybetmeden FX piyasasından kazanmasını sağlamak.

