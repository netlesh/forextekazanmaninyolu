## Presets

![ayarlar](../img/google_docs.svg)


[**Google Drive Bağlantısı**](https://drive.google.com/drive/folders/1bfID31XbvavNcOo1jj7HJzBB_QwR9-uV?usp=sharing )